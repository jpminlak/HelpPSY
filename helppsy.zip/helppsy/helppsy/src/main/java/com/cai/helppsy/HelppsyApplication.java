package com.cai.helppsy;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HelppsyApplication {

	public static void main(String[] args) {
		SpringApplication.run(HelppsyApplication.class, args);
	}

}
