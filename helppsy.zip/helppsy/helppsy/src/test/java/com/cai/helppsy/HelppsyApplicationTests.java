package com.cai.helppsy;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HelppsyApplicationTests {

	@Test
	void contextLoads() {
	}

}
