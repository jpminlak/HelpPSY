package viewtemp.vt1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Vt1Application {

	public static void main(String[] args) {
		SpringApplication.run(Vt1Application.class, args);
		System.out.println("시작");
	}
		
}
