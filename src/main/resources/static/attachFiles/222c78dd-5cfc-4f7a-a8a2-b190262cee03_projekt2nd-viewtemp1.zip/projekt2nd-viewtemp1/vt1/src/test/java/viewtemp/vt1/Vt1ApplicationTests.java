package viewtemp.vt1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Vt1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
